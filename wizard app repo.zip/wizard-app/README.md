# Wizard App

A small multi-step signup wizard built with React + Vite.

## Steps
1. **Account** — email, password, live availability check
2. **Profile** — name, role
3. **Review** — confirm and submit

Required fields are validated before the user can advance to the next step.
The account step also checks email availability against a mock API as the
user types (debounced).

## Development

```bash
npm install
npm run dev
```

## Testing

```bash
npm test
```

## Linting

```bash
npm run lint
```

## Requirements
- Node 20
- npm

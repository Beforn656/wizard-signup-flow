const TAKEN_EMAILS = new Set(['taken@example.com', 'admin@example.com']);

/**
 * Simulates a network call to check whether an email is available.
 * Delay is intentionally variable to mimic real-world network jitter,
 * so responses can resolve out of order relative to when they were sent.
 */
export function checkEmailAvailability(email) {
  const delay = 200 + Math.random() * 600;
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ email, available: !TAKEN_EMAILS.has(email.toLowerCase()) });
    }, delay);
  });
}

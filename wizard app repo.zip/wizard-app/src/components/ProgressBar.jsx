export default function ProgressBar({ steps, currentIndex }) {
  return (
    <ol className="progress-bar" aria-label="Wizard progress">
      {steps.map((label, i) => (
        <li key={label} aria-current={i === currentIndex ? 'step' : undefined}>
          {label}
        </li>
      ))}
    </ol>
  );
}

export default function Button({ variant = 'primary', ...props }) {
  return <button className={variant} {...props} />;
}

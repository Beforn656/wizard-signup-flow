import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import App from '../App.jsx';

async function fillAccountStep(user) {
  await user.type(screen.getByLabelText('Email'), 'person@example.com');
  await user.type(screen.getByLabelText('Password'), 'supersecret');
  await user.click(screen.getByRole('button', { name: 'Next' }));
}

describe('wizard navigation', () => {
  it('preserves entered values when moving back and forth between steps', async () => {
    const user = userEvent.setup();
    render(<App />);

    await fillAccountStep(user);
    expect(screen.getByRole('heading', { name: 'Profile' })).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Back' }));
    expect(screen.getByLabelText('Email')).toHaveValue('person@example.com');
    expect(screen.getByLabelText('Password')).toHaveValue('supersecret');
  });
});

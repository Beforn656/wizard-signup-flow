export function validateAccount(data) {
  const errors = {};
  if (!data.email) {
    errors.email = 'Email is required';
  } else if (!/^\S+@\S+\.\S+$/.test(data.email)) {
    errors.email = 'Enter a valid email address';
  }
  if (!data.password) {
    errors.password = 'Password is required';
  } else if (data.password.length < 8) {
    errors.password = 'Password must be at least 8 characters';
  }
  return errors;
}

export function validateProfile(data) {
  const errors = {};
  if (!data.fullName) {
    errors.fullName = 'Full name is required';
  }
  if (!data.role) {
    errors.role = 'Please select a role';
  }
  return errors;
}

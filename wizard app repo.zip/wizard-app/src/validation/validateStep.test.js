import { describe, expect, it } from 'vitest';
import { validateAccount, validateProfile } from './validateStep.js';

describe('validateAccount', () => {
  it('requires an email and password', () => {
    const errors = validateAccount({ email: '', password: '' });
    expect(errors.email).toBeTruthy();
    expect(errors.password).toBeTruthy();
  });

  it('rejects malformed emails', () => {
    const errors = validateAccount({ email: 'not-an-email', password: 'longenough' });
    expect(errors.email).toBeTruthy();
  });

  it('accepts a valid email and password', () => {
    const errors = validateAccount({ email: 'a@b.com', password: 'longenough' });
    expect(errors.email).toBeUndefined();
    expect(errors.password).toBeUndefined();
  });
});

describe('validateProfile', () => {
  it('requires full name and role', () => {
    const errors = validateProfile({ fullName: '', role: '' });
    expect(errors.fullName).toBeTruthy();
    expect(errors.role).toBeTruthy();
  });
});

import { act, renderHook } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { useWizardState } from './useWizardState.js';

describe('useWizardState', () => {
  it('updates individual fields without clobbering others', () => {
    const { result } = renderHook(() => useWizardState());

    act(() => result.current.updateField('email', 'a@b.com'));
    act(() => result.current.updateField('fullName', 'Jamie'));

    expect(result.current.data.email).toBe('a@b.com');
    expect(result.current.data.fullName).toBe('Jamie');
  });

  it('does not go below step 0', () => {
    const { result } = renderHook(() => useWizardState());
    act(() => result.current.goBack());
    expect(result.current.stepIndex).toBe(0);
  });
});

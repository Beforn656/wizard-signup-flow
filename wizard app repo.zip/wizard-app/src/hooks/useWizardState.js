import { useCallback, useState } from 'react';

const INITIAL_DATA = {
  email: '',
  password: '',
  fullName: '',
  role: '',
};

export function useWizardState() {
  const [stepIndex, setStepIndex] = useState(0);
  const [data, setData] = useState(INITIAL_DATA);

  const updateField = useCallback((field, value) => {
    setData((prev) => ({ ...prev, [field]: value }));
  }, []);

  const goNext = useCallback(() => {
    setStepIndex((i) => i + 1);
  }, []);

  const goBack = useCallback(() => {
    setStepIndex((i) => Math.max(0, i - 1));
  }, []);

  return { stepIndex, data, updateField, goNext, goBack };
}

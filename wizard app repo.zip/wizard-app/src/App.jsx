import { useEffect, useMemo, useRef, useState } from 'react';
import { useWizardState } from './hooks/useWizardState.js';
import { validateAccount, validateProfile } from './validation/validateStep.js';
import ProgressBar from './components/ProgressBar.jsx';
import Button from './components/Button.jsx';
import StepAccount from './steps/StepAccount.jsx';
import StepProfile from './steps/StepProfile.jsx';
import StepReview from './steps/StepReview.jsx';

const STEPS = ['Account', 'Profile', 'Review'];

export default function App() {
  const { stepIndex, data, updateField, goNext, goBack } = useWizardState();
  const [submitted, setSubmitted] = useState(false);
  const [attemptedNext, setAttemptedNext] = useState(false);
  const headingRef = useRef(null);

  useEffect(() => {
    headingRef.current?.focus();
  }, [stepIndex]);

  const errors = useMemo(() => {
    if (stepIndex === 0) return validateAccount(data);
    if (stepIndex === 1) return validateProfile(data);
    return {};
  }, [stepIndex, data]);

  const hasErrors = Object.keys(errors).length > 0;

  if (submitted) {
    return (
      <div className="wizard">
        <h1>You're all set!</h1>
        <p>Thanks, {data.fullName || 'friend'}. Your account has been created.</p>
      </div>
    );
  }

  const handleNext = () => {
    setAttemptedNext(true);
    if (!hasErrors) {
      setAttemptedNext(false);
      goNext();
    }
  };

  const handleBack = () => {
    setAttemptedNext(false);
    goBack();
  };

  const visibleErrors = attemptedNext ? errors : {};

  const steps = [
    <StepAccount key="account" data={data} updateField={updateField} errors={visibleErrors} />,
    <StepProfile key="profile" data={data} updateField={updateField} errors={visibleErrors} />,
    <StepReview key="review" data={data} />,
  ];

  const isLastStep = stepIndex === steps.length - 1;

  return (
    <div className="wizard">
      <ProgressBar steps={STEPS} currentIndex={stepIndex} />
      <h1 tabIndex={-1} ref={headingRef}>
        {STEPS[stepIndex]}
      </h1>
      {steps[stepIndex]}
      <div className="actions">
        <Button variant="secondary" onClick={handleBack} disabled={stepIndex === 0}>
          Back
        </Button>
        {isLastStep ? (
          <Button variant="primary" onClick={() => setSubmitted(true)}>
            Submit
          </Button>
        ) : (
          <Button variant="primary" onClick={handleNext}>
            Next
          </Button>
        )}
      </div>
    </div>
  );
}

const ROLES = ['Engineer', 'Designer', 'Product Manager', 'Other'];

export default function StepProfile({ data, updateField, errors }) {
  return (
    <div>
      <h2>Profile</h2>
      <p className="step-hint">Tell us a bit about yourself.</p>
      <div className="field">
        <label htmlFor="fullName">Full name</label>
        <input
          id="fullName"
          type="text"
          autoComplete="name"
          value={data.fullName}
          onChange={(e) => updateField('fullName', e.target.value)}
        />
        {errors.fullName && <span className="field-error">{errors.fullName}</span>}
      </div>
      <div className="field">
        <label htmlFor="role">Role</label>
        <select
          id="role"
          value={data.role}
          onChange={(e) => updateField('role', e.target.value)}
        >
          <option value="">Select a role</option>
          {ROLES.map((role) => (
            <option key={role} value={role}>
              {role}
            </option>
          ))}
        </select>
        {errors.role && <span className="field-error">{errors.role}</span>}
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useDebouncedValue } from '../hooks/useDebouncedValue.js';
import { checkEmailAvailability } from '../api/checkEmailAvailability.js';

export default function StepAccount({ data, updateField, errors }) {
  const [availability, setAvailability] = useState(null); // null | 'checking' | 'available' | 'unavailable'
  const debouncedEmail = useDebouncedValue(data.email, 300);

  useEffect(() => {
    if (!debouncedEmail || !/^\S+@\S+\.\S+$/.test(debouncedEmail)) {
      setAvailability(null);
      return;
    }

    setAvailability('checking');

    checkEmailAvailability(debouncedEmail).then((result) => {
      setAvailability(result.available ? 'available' : 'unavailable');
    });
  }, [debouncedEmail]);

  return (
    <div>
      <h2>Account</h2>
      <div className="field">
        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          value={data.email}
          onChange={(e) => updateField('email', e.target.value)}
          aria-describedby="email-status"
        />
        {errors.email && <span className="field-error">{errors.email}</span>}
        <span id="email-status" className="status-text" role="status" aria-live="polite">
          {availability === 'checking' && 'Checking availability…'}
          {availability === 'available' && 'Email is available'}
          {availability === 'unavailable' && 'Email is already taken'}
        </span>
      </div>
      <div className="field">
        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          autoComplete="new-password"
          value={data.password}
          onChange={(e) => updateField('password', e.target.value)}
        />
        {errors.password && <span className="field-error">{errors.password}</span>}
      </div>
    </div>
  );
}

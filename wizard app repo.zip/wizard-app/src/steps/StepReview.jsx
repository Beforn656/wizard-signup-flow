export default function StepReview({ data }) {
  return (
    <div>
      <h2>Review</h2>
      <p className="step-hint">Double check your details before submitting.</p>
      <dl>
        <dt>Email</dt>
        <dd>{data.email}</dd>
        <dt>Full name</dt>
        <dd>{data.fullName}</dd>
        <dt>Role</dt>
        <dd>{data.role}</dd>
      </dl>
    </div>
  );
}

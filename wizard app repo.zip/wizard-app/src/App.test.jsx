import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import App from './App.jsx';

describe('App wizard', () => {
  it('renders the first step by default', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: 'Account' })).toBeInTheDocument();
  });

  it('blocks navigation when required fields are missing', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('button', { name: 'Next' }));
    expect(screen.getByRole('heading', { name: 'Account' })).toBeInTheDocument();
    expect(screen.getByText('Email is required')).toBeInTheDocument();
  });
});

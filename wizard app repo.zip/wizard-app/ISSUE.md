# Known issue: stale email availability result can overwrite a newer one

## Summary
On the Account step, typing an email triggers a debounced call to
`checkEmailAvailability`. The mock API has variable latency to simulate
real network jitter. If an earlier request happens to resolve *after* a
later one (e.g. the user edits the email again shortly after the first
check fires), the UI can end up showing the availability status for an
email the user is no longer looking at.

## Steps to reproduce
1. Type an email address that resolves slowly.
2. Before the check finishes, change the email to a different address
   whose check resolves quickly.
3. Watch the status text — it can flip back to reflect the first
   (now-stale) email after the second, correct result already rendered.

## Expected behavior
The status shown should always reflect the availability of the email
currently in the input, even when responses arrive out of order.
